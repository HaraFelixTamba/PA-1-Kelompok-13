<?php
include ("koneksi.php");
 if(isset($_POST['Bansos'])){
    $Pengirim = $_POST['Pengirim'];
    $Nomor_telephone = $_POST['Nomor_telephone'];			
    $Alamat = $_POST['Alamat'];
    $Jenis_Bansos = $_POST['Jenis_Bansos'];
    $Alasan = $_POST['Alasan'];
    $image = $_FILES['image']['name'];
	$letak= $_FILES['image']['tmp_name'];
	copy ($letak,"assets/images_bansos/".$image);
    $sql = "insert into bansos values ('$Pengirim','$Nomor_telephone','$Alamat','$Jenis_Bansos','$Alasan','$image')";
    $query = mysqli_query($koneksi,$sql);
    if($query){
      echo"<script> alert(\"berhasil\"); window.location = \"Index.php\"; </script>";;
      }else{
      echo "<script> alert(\"Maaf!! Silakan Cek Kembali Form Yang Telah Anda Isi\"); window.location = \"index.php\"; </script>";
      }
}
?>