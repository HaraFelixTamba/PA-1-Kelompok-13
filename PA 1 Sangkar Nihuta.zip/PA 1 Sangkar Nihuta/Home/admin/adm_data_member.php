<div class="right_col" role="main">
          <div class="">

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Data Member</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                  		<!-- Isi disini -->
                       <!-- Tabel Data Member -->
                      <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>Username</th>
                          <th>Nama</th>
                          <th>No telepon</th>
                          <th>email</th>
                          <th>Password</th>
                        </tr>
                      </thead>


                      <tbody>
                       <?php 
						require "../koneksi.php";
						$query = mysqli_query($koneksi,"select * from member");// Variabel berisi perintah untuk memilih data di tabel lapangan di database
						while($sel = mysqli_fetch_array($query)){//membuat data yang telah di pilih menjadi bentuk array
						?>
                        <tr>
                         <!-- menampilkan data dari tabel member pada database -->
                          <td><?php echo $sel['username_member']; ?></td>
                          <td><?php echo $sel['nama']; ?></td>
                          <td><?php echo $sel['No_telephone']; ?></td>
                          <td><?php echo $sel['email']; ?></td>
                          <td><?php echo $sel['password']; ?></td>
                        </tr>
                        <?php } ?>
                      </tbody>
                    </table>
                   
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>