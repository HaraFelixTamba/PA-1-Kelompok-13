<div class="right_col" role="main">
          <div class="">

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Jadwal Surat</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                  		<!-- Isi disini -->
                     <!-- Tabel Data Pemesanan Offline -->
                      <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="x_content">
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                         <th>Nama lengkap</th>
                        <th>No telephone</th>
                        <th>Jenis surat</th>
                        <th>Tanggal</th>
                        <th>Jam datang</th>
                        </tr>
                      </thead>


                      <tbody>
                       <?php 
		$sql_sel = "select * from jadwal"; //variabel berisi bahasa query untuk memilih data di tabel transaksi yang jenis bayar = off cod (pesan langsung kepada operator tempat futsal)
		$query_sel = mysqli_query($koneksi,$sql_sel);// merubah menjadi bahasa query agar dapat memilih data di database
		while($sql_res = mysqli_fetch_array($query_sel)){//merubah data yang telah dipilih menjadi bentuk array
											
	?>
          <tr>
            <!-- menampilkan data yang telah dipilih dalam bentuk tabel -->
             <td><?php echo $sql_res['Nama_lengkap']; ?></td>
             <td><?php echo $sql_res['No_telephone']; ?></td>
             <td><?php echo $sql_res['Jenis_surat']; ?></td>
             <td><?php echo $sql_res['Tanggal']; ?></td>
             <td><?php echo $sql_res['Jam_datang']; ?></td>
             </tr>
    <?php }?>
                      </tbody>
                    </table>
                     </div>
                </div>
              </div>
            </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>