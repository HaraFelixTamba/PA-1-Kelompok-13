<div class="right_col" role="main">
          <div class="">

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Bantuan Sosial</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                  		<!-- Isi disini -->
                      <!-- Tabel Data Pemesanan Online -->
                     <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="x_content">
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                         <th>Pengirim</th>
                        <th>Nomor telephone</th>
                        <th>Alamat</th>
                        <th>Jenis Bansos</th>
                        <th>Alasan</th>
                        <th>image</th>
                        </tr>
                      </thead>


                      <tbody>
                       <?php 
		$sql_sel = "select * from bansos"; //variabel berisi bahasa query untuk memilih data di tabel transaksi yang jenis bayar = transfer atau cod
		$query_sel = mysqli_query($koneksi,$sql_sel); // merubah menjadi bahasa query agar dapat memilih data di database
		while($sql_res = mysqli_fetch_array($query_sel)){ //merubah data yang telah dipilih menjadi bentuk array
											
	?>
          <tr>
            <!-- menampilkan data yang telah dipilih dalam bentuk tabel -->
             <td><?php echo $sql_res['Pengirim']; ?></td>
             <td><?php echo $sql_res['Nomor_telephone']; ?></td>
             <td><?php echo $sql_res['Alamat']; ?></td>
             <td><?php echo $sql_res['Jenis_Bansos']; ?></td>
             <td><?php echo $sql_res['Alasan']; ?></td>
             <td><img align="middle" src="../assets/images_bansos/<?php echo $sql_res['image']; ?>" style="width:100px; height:50px;"></td>
             </td>
             </tr>
    <?php }?>
                      </tbody>
                    </table>
                     </div>
                </div>
              </div>
            </div>
             
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>