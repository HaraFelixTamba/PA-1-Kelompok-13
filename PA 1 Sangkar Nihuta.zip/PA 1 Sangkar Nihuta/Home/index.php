<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sangkar Nihuta || Home</title>
  <link rel="shortcut icon" href="assets/images/Logo toba.jpg">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="assets/css/w3.css">
    <link rel="stylesheet" href="assets/css/w3-theme-blue-grey.css">
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    
    <style>
  	body { 
			background-image: url("assets/images/bg.jpg");	
      background-repeat: no-repeat;
      background-size: cover;
      background-position: center;
      background-attachment: fixed;
      height: 100%;
  }
  .title {
    text-align: center;
    font-size: 2.5em;
    font-family: Times New Roman;
    font-weight: bold;
    color: #EB0000;
    margin-top: 150px;
  }
  .title2 {
    text-align: center;
    font-size: 2.0em;
    font-family: Times New Roman;
    font-weight: bold;
    color: #FFF9F9;
    margin-top: 20px;
  }
  </style> 
</head>
<body>
<h2 class="title">SELAMAT DATANG DI WEBSITE SANGKAR NIHUTA</h2>
<h4 class="title2">Media Informasi Desa Sangkar Nihuta</h4>
<?php
  include "navbar.php";
  include "member_login.php";
?>
</body>
</html>