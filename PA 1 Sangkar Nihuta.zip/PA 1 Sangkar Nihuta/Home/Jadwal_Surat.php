<?php
require ("koneksi.php");
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if(isset($_SESSION['member'])){
	$username = $_SESSION['member'];
	$sql = "select * from member where username_member = '$username'";
	$query_sel = mysqli_query($koneksi,$sql);
	$sql_sel = mysqli_fetch_array($query_sel);
	?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sangkar Nihuta</title>
  <meta charset="utf-8">
  <link rel="shortcut icon" href="assets/images/Logo toba.jpg">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <link href="assets/css/bootstrap-datetimepicker.min.css" rel="stylesheet">
  <style media="screen">
  	body { padding-top: 70px; }
    h3, h5 {

      color: #424e5e;
    }
    h4{
      color: 	#d34e5b;
    }

  </style>
</head>
<body>
<?php
include ("koneksi.php");
 if(isset($_POST['jadwal'])){
    $Nama_lengkap = $_POST['Nama_lengkap'];
    $No_telephone = $_POST['No_telephone'];			
    $Jenis_surat = $_POST['Jenis_surat'];
    $Tanggal = $_POST['Tanggal'];
    $Jam_datang = $_POST['Jam_datang'];
    $sql = "INSERT into jadwal values ('$Nama_lengkap','$No_telephone','$Jenis_surat','$Tanggal','$Jam_datang')";
    $query = mysqli_query($koneksi,$sql);
    if($query){
      echo"<script> alert(\"Pembuatan jadwal berhasil\"); window.location = \"Index.php\"; </script>";;
      }else{
      echo "<script> alert(\"Maaf!! Silakan Cek Kembali Form Yang Telah Anda Isi\"); window.location = \"index.php\"; </script>";
      }
}
?>
<nav class="navbar navbar-default navbar-fixed-top bg-primary">
        <div class="container-fluid">
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <img src="assets/images/Logo toba.jpg">
          </div>

          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">Website Desa Sangkar Nihuta</a>
          </div>

          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav navbar-right">
          <li class="w3-hide-small w3-dropdown-hover">
          <a href="index.php" class="w3-padding-large w3-hover-white">Kembali</a>
          </li>
          </ul>

          </div>
</nav>
<div class="container">
    <h3><b>Jadwal Pengurusan Surat</b></h3>
    <hr>
    <div class="row">
      <div class="col-sm-1"></div>
      <div class="col-sm-3"></div>
      <div class="col-sm-8">

      </div>
    </div>
    <form class="form-horizontal" action="" method="post">
      <div class="form-group">
        <div class="col-sm-1"></div>
        <div class="col-sm-3"></div>
        <div class="col-sm-8">
          <h3><b>Membuat Jadwal</b></h3>
        </div>
      </div>

      <div class="form-group">
        <div class="col-sm-1"></div>
        <label class="control-label col-sm-3" for="email">Nama Lengkap</label>
        <div class="col-sm-4">
          <input type="text" class="form-control" name="Nama_lengkap" id="pwd" placeholder="Nama Lengkap" required>
        </div>
        <div class="col-sm-4"></div>
      </div>
      
      <div class="form-group">
        <div class="col-sm-1"></div>
        <label class="control-label col-sm-3" for="email">No.telephone</label>
        <div class="col-sm-4">
          <input type="number" class="form-control" name="No_telephone" id="pwd" placeholder="No_telephone" required>
        </div>
        <div class="col-sm-4"></div>
      </div>

       <div class="form-group">
        <div class="col-sm-1"></div>
        <label class="control-label col-sm-3" for="email">Jenis surat</label>
        <div class="col-sm-4">
          <input type="text" class="form-control" name="Jenis_surat" id="pwd" placeholder="Jenis_surat" required>
        </div>
        <div class="col-sm-4"></div>
      </div>
      
       <div class="form-group">
        <div class="col-sm-1"></div>
        <label class="control-label col-sm-3" for="email">Tanggal Pengurusan</label>
        <div class="col-sm-4">
           <div class='input-group date' id='datepicker'>
                                <input type='text' class="form-control" name="Tanggal" value="2022-02-06" required/>
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
        </div>
        <div class="col-sm-4"></div>
      </div>

        <div class="form-group">
        <div class="col-sm-1"></div>
        <label class="control-label col-sm-3" for="email">Waktu kedatangan</label>
        <div class="col-sm-4">
          <input type="Time" class="form-control" name="Jam_datang" id="pwd" placeholder="Jam_datang" required>
        </div>
        <div class="col-sm-4"></div>
      </div>

              <div class="row">
                <div class="col-sm-5"></div>
                <div class="col-sm-2">
                  <button type="submit" class="btn btn-danger btn-block" name="jadwal">Submit</button>
                </div>
                <div class="col-sm-5"></div>
              </div>
        </div>

    </form>
    
  </div>
  <br><br><br><br><br>
</body>
<!-- jQuery -->
    <script src="admin/assets/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="admin/assets/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="admin/assets/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="admin/assets/vendors/nprogress/nprogress.js"></script>
  <!-- jQuery Smart Wizard -->
    <script src="admin/assets/vendors/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="admin/assets/build/js/custom.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="assets/min/moment.min.js"></script>
    <script src="admin/assets/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="assets/js/moment.js"></script>
<script src="assets/js/bootstrap-datetimepicker.min.js"></script>
		<script type="text/javascript">
			$(function () {
				$('#datetimepicker').datetimepicker({
					format: 'DD MMMM YYYY HH:mm',
                });
				
				$('#datepicker').datetimepicker({
					format: 'YYYY-MM-DD',
				});
				
				$('#timepicker').datetimepicker({
					format: 'HH:mm'
				});
			});
		</script>
</html>
<?php 
}else {
    echo "<script> alert(\"Silakan Login Sebagai Member\"); window.location = \"index.php\" </script>";
  }
?>
