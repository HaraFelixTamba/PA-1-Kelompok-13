<?php
$koneksi = mysqli_connect("localhost", "root","","db_website_sangkar_nihuta");
    if(!($koneksi)){
        echo "<script language=\"javascript\">\n";
        echo "alert(\"Tidak bisa terkoneksi dengan database...\");\n";
        echo "</script>";
        die;
    }else{
        $select = mysqli_select_db($koneksi, "db_website_sangkar_nihuta");
        //echo "Sukses";
    }
?>
