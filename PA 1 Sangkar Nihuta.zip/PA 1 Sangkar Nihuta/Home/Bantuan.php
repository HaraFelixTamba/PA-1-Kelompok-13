<?php
require ("koneksi.php");
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if(isset($_SESSION['member'])){
	$username = $_SESSION['member'];
	$sql = "select * from member where username_member = '$username'";
	$query_sel = mysqli_query($koneksi,$sql);
	$sql_sel = mysqli_fetch_array($query_sel);
	?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sangkar Nihuta</title>
  <meta charset="utf-8">
  <link rel="shortcut icon" href="assets/images/Logo toba.jpg">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <link href="assets/css/bootstrap-datetimepicker.min.css" rel="stylesheet">
  <style media="screen">
  	body { padding-top: 70px; }
    h3, h5 {

      color: #424e5e;
    }
    h4{
      color: 	#d34e5b;
    }

</style>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top bg-primary">
        <div class="container-fluid">
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <img src="assets/images/Logo toba.jpg">
          </div>

          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">Website Desa Sangkar Nihuta</a>
          </div>

          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          <ul class="nav navbar-nav navbar-right">
          <li class="w3-hide-small w3-dropdown-hover">
          <a href="index.php" class="w3-padding-large w3-hover-white">Kembali</a>
          </li>
          </ul>

          </div>
</nav>
<div class="container">
    <h3><b>Form Bantuan Sosial</b></h3>
    <hr>
    <div class="row">
      <div class="col-sm-1"></div>
      <div class="col-sm-3"></div>
      <div class="col-sm-8">

      </div>
    </div>
    <form class="form-horizontal" action="BantuanPHP.php" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <div class="col-sm-1"></div>
        <div class="col-sm-3"></div>
        <div class="col-sm-8">
          <h3><b>Bantuan Sosial</b></h3>
        </div>
      </div>

      <div class="form-group">
        <div class="col-sm-1"></div>
        <label class="control-label col-sm-3" for="email">Pengirim</label>
        <div class="col-sm-4">
          <input type="text" class="form-control" name="Pengirim" id="pwd" placeholder="Pengirim" required>
        </div>
        <div class="col-sm-4"></div>
      </div>
      
      <div class="form-group">
        <div class="col-sm-1"></div>
        <label class="control-label col-sm-3" for="email">Nomor telephone</label>
        <div class="col-sm-4">
          <input type="number" class="form-control" name="Nomor_telephone" id="pwd" placeholder="Nomor_telephone" required>
        </div>
        <div class="col-sm-4"></div>
      </div>

       <div class="form-group">
        <div class="col-sm-1"></div>
        <label class="control-label col-sm-3" for="email">Alamat</label>
        <div class="col-sm-4">
          <input type="text" class="form-control" name="Alamat" id="pwd" placeholder="Alamat" required>
        </div>
        <div class="col-sm-4"></div>
      </div>

      <div class="form-group">
        <div class="col-sm-1"></div>
        <label class="control-label col-sm-3" for="email">Alasan Pegiriman bantuan</label>
        <div class="col-sm-4">
          <input type="text" class="form-control" name="Alasan" id="pwd" placeholder="Alasan" required>
        </div>
        <div class="col-sm-4"></div>
      </div>

      <div class="form-group">
        <div class="col-sm-1"></div>
        <label class="control-label col-sm-3" for="email">Jenis Bantuan</label>
        <div class="col-sm-4">
          <input type="text" class="form-control" name="Jenis_Bansos" id="pwd" placeholder="Jenis_Bansos" required>
        </div>
        <div class="col-sm-4"></div>
      </div>

      <div class="form-group">
                <div class="col-sm-1"></div>
                <label class="control-label col-sm-3" for="email">Foto Bansos</label>
                <div class="col-sm-8">
                  <label class="btn btn-info" for="my-file-selector2">
                      <input id="my-file-selector2" name="image" required type="file" style="display:none;" onchange="$('#upload-file-foto').html($(this).val());">
                      Upload Foto
                  </label>
                  <p>* Ukuran file maksimal kurang dari 2 MB</p>
                  <span class='label label-danger' id="upload-file-foto"></span>
                </div>

              </div>

              <div class="row">
                <div class="col-sm-5"></div>
                <div class="col-sm-2">
                  <button type="submit" class="btn btn-danger btn-block" name="Bansos">Submit</button>
                </div>
                <div class="col-sm-5"></div>
              </div>

    </form>
    
  </div>
  <br><br><br><br><br>
</body>
<!-- jQuery -->
    <script src="admin/assets/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="admin/assets/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="admin/assets/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="admin/assets/vendors/nprogress/nprogress.js"></script>
  <!-- jQuery Smart Wizard -->
    <script src="admin/assets/vendors/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="admin/assets/build/js/custom.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="assets/min/moment.min.js"></script>
    <script src="admin/assets/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="assets/js/moment.js"></script>
<script src="assets/js/bootstrap-datetimepicker.min.js"></script>
		<script type="text/javascript">
			$(function () {
				$('#datetimepicker').datetimepicker({
					format: 'DD MMMM YYYY HH:mm',
                });
				
				$('#datepicker').datetimepicker({
					format: 'YYYY-MM-DD',
				});
				
				$('#timepicker').datetimepicker({
					format: 'HH:mm'
				});
			});
		</script>
</html>
<?php 
}else {
    echo "<script> alert(\"Silakan Login Sebagai Member\"); window.location = \"index.php\" </script>";
  }
?>
