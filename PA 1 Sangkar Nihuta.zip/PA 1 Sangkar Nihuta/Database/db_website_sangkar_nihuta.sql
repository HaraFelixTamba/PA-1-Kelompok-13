-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 12 Jun 2022 pada 03.17
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_website_sangkar_nihuta`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` varchar(20) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(20) NOT NULL,
  `foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `nama`, `email`, `password`, `foto`) VALUES
('Hara', 'Haratama', 'Haratama@gmail.com', '12', 'dua.jpg'),
('jefta', 'Jefta ', 'Jefta23@gmail.com', '2', '6.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `bansos`
--

CREATE TABLE `bansos` (
  `Pengirim` varchar(255) NOT NULL,
  `Nomor_telephone` varchar(255) NOT NULL,
  `Alamat` varchar(255) NOT NULL,
  `Jenis_Bansos` varchar(500) NOT NULL,
  `Alasan` varchar(500) NOT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `bansos`
--

INSERT INTO `bansos` (`Pengirim`, `Nomor_telephone`, `Alamat`, `Jenis_Bansos`, `Alasan`, `image`) VALUES
('Pt.Bansos', '12121212', 'Jl.sederhana Medan', 'Beras dan bahan pokok', 'Bantuan Kemanusiaan', 'Kel._Sangkar_Nihuta,_Balige,_Toba_Samosir_02.jpg'),
('Pt.harapan Mandiri', '08224433', 'Jl.diponegoro medan', 'Minyak dan bahan pokok', 'Bantuan Kemanusiaan', '98413-ilustrasi-blt.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jadwal`
--

CREATE TABLE `jadwal` (
  `Nama_lengkap` varchar(255) NOT NULL,
  `No_telephone` varchar(11) NOT NULL,
  `Jenis_surat` varchar(255) NOT NULL,
  `Tanggal` date NOT NULL,
  `Jam_datang` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `jadwal`
--

INSERT INTO `jadwal` (`Nama_lengkap`, `No_telephone`, `Jenis_surat`, `Tanggal`, `Jam_datang`) VALUES
('Haratama Felix Tamba', '08136626262', 'Kartu keluarga', '2022-06-02', '14:05:00'),
('Haratama Felix Tamba', '121212121', 'Kartu keluarga', '2022-02-24', '23:06:00'),
('Arjuna batubara', '08123456789', 'KTP', '2022-06-10', '09:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `member`
--

CREATE TABLE `member` (
  `username_member` varchar(30) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `No_telephone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `member`
--

INSERT INTO `member` (`username_member`, `nama`, `No_telephone`, `email`, `password`) VALUES
('jefta12', 'Jefta Wijaya Manurung', '082272033484', 'jeftamanurung12@gmail.com', 'jefta12');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`username_member`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
